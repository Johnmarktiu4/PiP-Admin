import ComponentCard from "@/components/common/ComponentCard";
import PageBreadcrumb from "@/components/common/PageBreadCrumb";
import BasicTableOne from "@/components/tables/BasicTableOne";
import { Metadata } from "next";
import React from "react";
import PointOfSale from "@/components/pos/PointOfSale";
import DefaultInputs from "@/components/form/form-elements/DefaultInputs";

export const metadata: Metadata = {
  title: "Mr. Snow Admin",
  description:
    "",
  // other metadata
};

export default function POS() {
  return (
    <div className="grid grid-cols-12 gap-4 md:gap-6">
      <div className="col-span-12 space-y-6 xl:col-span-12">
        <PageBreadcrumb pageTitle="Menu" />
        <div className="space-y-6">
          <ComponentCard title="POS Menu">
            <PointOfSale />
          </ComponentCard>
        </div>
      </div>

     
    </div>
  );
}
